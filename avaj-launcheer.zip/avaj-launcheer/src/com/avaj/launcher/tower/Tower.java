package com.avaj.launcher.tower;

public class Tower {
}
