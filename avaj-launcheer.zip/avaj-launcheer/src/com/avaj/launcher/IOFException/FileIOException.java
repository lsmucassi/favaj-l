package com.avaj.launcher.IOFException;

import java.io.IOException;

public class FileIOException extends IOException {

}
