package com.avaj.launcher.aircraft;

public class Helicopter {
}
