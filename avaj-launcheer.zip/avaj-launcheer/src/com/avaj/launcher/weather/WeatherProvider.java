package com.avaj.launcher.weather;

public class WeatherProvider {
}
