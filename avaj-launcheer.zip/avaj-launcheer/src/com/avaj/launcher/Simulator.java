package com.avaj.launcher;

import com.avaj.launcher.aircraft.AircraftFactory;
import com.avaj.launcher.tower.WeatherTower;

import java.io.File;
import java.io.PrintWriter;
import java.sql.SQLOutput;

public class
Simulator {

    public static PrintWriter printer;
    public static int iter;

    public static void main(String[] args) {

        if (args.length != 1) {
            System.out.println("Error: program needs one file name passed as an argument");
            System.out.println("Try: $javac -sourcepath @sources.txt");
            return ;
        }

        AircraftFactory aCraft = new AircraftFactory();
        WeatherTower opTower = new WeatherTower();

        String scenarioFile = args[0];
        File simFile = new File("simulation.txt");

        try {
            printer = new PrintWriter(simFile);
        } catch () {
            System.out.println("Error: couln't print to file");
        }


    }
}
